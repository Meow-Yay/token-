#!/usr/bin/env node
/**
 * install.mjs — install or remove the `tokenskip-context` skill.
 *
 * Portable: the skill source is the directory this file lives in, so the whole
 * `tokenskip-context/` folder can be copied anywhere and installed from there.
 *
 *   node install.mjs              install
 *   node install.mjs --uninstall  remove
 *   node install.mjs --status     report only
 *
 * The target plugin root defaults to <DSH_HOME>/plugins/dsh-codex-skills and can
 * be overridden with DSH_CODEX_SKILLS_PLUGIN.
 */

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const SKILL = 'tokenskip-context';
const SOURCE = path.dirname(fileURLToPath(import.meta.url));

function pluginRoot() {
  if (process.env.DSH_CODEX_SKILLS_PLUGIN) return process.env.DSH_CODEX_SKILLS_PLUGIN;
  const home = process.env.DSH_HOME || path.join(os.homedir(), '.dsh');
  return path.join(home, 'plugins', 'dsh-codex-skills');
}

const PLUGIN = pluginRoot();
const TARGET = path.join(PLUGIN, 'skills', SKILL);
const CATALOG = path.join(PLUGIN, 'catalog.json');

const argv = process.argv.slice(2);
const uninstall = argv.includes('--uninstall');
const statusOnly = argv.includes('--status');

const sha = (p) => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex').slice(0, 12);
const readCatalog = () => JSON.parse(fs.readFileSync(CATALOG, 'utf8'));
const writeCatalog = (c) => fs.writeFileSync(CATALOG, JSON.stringify(c, null, 2) + '\n', 'utf8');
const findIndex = (c) => c.skills.findIndex((s) => s.name === SKILL);

function frontmatterDescription() {
  const raw = fs.readFileSync(path.join(SOURCE, 'SKILL.md'), 'utf8');
  const m = raw.match(/^---\n([\s\S]*?)\n---/);
  if (!m) return '';
  const d = m[1].match(/^description:\s*(.+)$/m);
  return d ? d[1].trim() : '';
}

if (!fs.existsSync(CATALOG)) {
  console.error('catalog.json not found at ' + CATALOG);
  console.error('Set DSH_CODEX_SKILLS_PLUGIN to the dsh-codex-skills plugin root.');
  process.exit(2);
}

if (statusOnly) {
  const c = readCatalog();
  const i = findIndex(c);
  console.log(`skill           : ${SKILL}`);
  console.log(`source          : ${SOURCE} ${fs.existsSync(path.join(SOURCE, 'SKILL.md')) ? 'ok' : 'MISSING'}`);
  console.log(`installed bundle: ${TARGET} ${fs.existsSync(path.join(TARGET, 'SKILL.md')) ? 'ok' : 'MISSING'}`);
  console.log(`catalog entry   : ${i >= 0 ? 'present (index ' + i + ')' : 'absent'}`);
  console.log(`catalog skills  : ${c.skills.length}`);
  process.exit(0);
}

if (uninstall) {
  const c = readCatalog();
  const i = findIndex(c);
  if (i >= 0) {
    c.skills.splice(i, 1);
    c.stats = c.stats || {};
    c.stats.skillCount = c.skills.length;
    writeCatalog(c);
    console.log('catalog entry removed');
  } else {
    console.log('catalog entry already absent');
  }
  fs.rmSync(TARGET, { recursive: true, force: true });
  console.log('bundle removed from plugin: ' + TARGET);
  process.exit(0);
}

// install
const description = frontmatterDescription();
if (!description) throw new Error('no description: found in SKILL.md frontmatter');

fs.mkdirSync(TARGET, { recursive: true });
for (const rel of ['SKILL.md', path.join('agents', 'openai.yaml')]) {
  const src = path.join(SOURCE, rel);
  const dst = path.join(TARGET, rel);
  if (!fs.existsSync(src)) throw new Error('missing source file: ' + src);
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
  console.log(`  copied ${rel} (${sha(dst)})`);
}

const c = readCatalog();
const existing = findIndex(c);
if (existing >= 0) {
  c.skills[existing].description = description;
  console.log('catalog entry updated (index ' + existing + ')');
} else {
  const entry = {
    name: SKILL,
    dir: SKILL,
    file: 'SKILL.md',
    description,
    modelInvocable: true,
    userInvocable: true,
    metadata: {},
  };
  let at = c.skills.findIndex((s) => s.name.localeCompare(SKILL, 'en') > 0);
  if (at === -1) at = c.skills.length;
  c.skills.splice(at, 0, entry);
  console.log('catalog entry inserted at index ' + at);
}
c.stats = c.stats || {};
c.stats.skillCount = c.skills.length;
writeCatalog(c);

const check = readCatalog();
const ok = findIndex(check) >= 0 && fs.existsSync(path.join(TARGET, 'SKILL.md'));
console.log(`\nverify: ${ok ? 'OK' : 'FAILED'} — ${check.skills.length} skills in catalog`);
process.exit(ok ? 0 : 1);
